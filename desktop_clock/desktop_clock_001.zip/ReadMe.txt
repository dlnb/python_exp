	
Intro:
1.可以选择正向计时，倒计时，以及当前时间
2.窗口可设置置顶显示，可以自行设置透明度和窗口颜色
BuildInfomation:
version: 0.0.1
author: dlnb526
buildtime:2020.02.12
statement:original version
----------------
		