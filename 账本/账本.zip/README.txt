	Statement:嘿嘿这是一个简单的账本程序，由于明文存储密码，所以要注意隐私安全哦！
	Ver: 0.0.1
	BuildDate:2020.02.10
	Author:dlnb526
	---------------------
	Ver: 0.0.2
	BuildDate:2020.02.10
	Author:dlnb526
	Statement:修复了另存为窗口打不开的问题
	